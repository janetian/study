#ifndef foshow_h
#define foshow_h
#include "Global.h"



class foshow
{
	void drawhextitle();
	void drawbsttitle();
	void drawmaintitle();
public:
	bool summonthegraphics();
	void titlescreen();
	void redrawtitle();
	void drawbstmenue(bool BunchofSpacesAtEnd1, bool True_for_x_to_exit, bool True_for_displaying_options);
	void drawhexmenue(bool BunchofSpacesAtEnd1,bool True_for_x_to_exit, bool True_for_displaying_options);
	void drawmainmenue();
	void s();
};

#endif