//
//  main.cpp
//  FinalProject
//
//  Created by Xiaojing Liu on 11/5/15.
//  Copyright � 2015 Xiaojing Liu. All rights reserved.
//


#include <iostream>
#include "bstNode.hpp"
#include "bst.h"
#include "foshow.h"
#include "HashTable.h"
#include "Global.h"



//Overloads enum cout to output enum name
ostream& operator<<(std::ostream& out, const myenum value);

//	SetConsoleTextAttribute(hConsole, 116); red
//SetConsoleTextAttribute(hConsole, 112); normal
//SetConsoleTextAttribute(hConsole, 240); bright white back
// foreground + background * 16 4+12*16
//system("color f7")
//PlaySound(NULL, NULL, SND_FILENAME | SND_LOOP | SND_ASYNC); to stop the music

int main()
{
	//system("Color 512");
	HANDLE  hConsole;
	hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
	foshow hot;
	HashTable help;
	string choice;
	hot.summonthegraphics();
	hot.titlescreen();
	bst kind;
	hot.s();
	do{
		hot.drawmainmenue();
		SetConsoleTextAttribute(hConsole, 124);
		getline(cin, choice);
		SetConsoleTextAttribute(hConsole, 112);
		if (choice == "bst")
			kind.bstmenue();
		else if (choice == "hash")
		{
			help.hashmenue();
		}
		else if (choice == "x")
		{
		}
	} while (choice != "x");
	remove("temp.txt");
}

ostream& operator<<(std::ostream& out, const myenum value)
{
	const char* s = 0;
#define PROCESS_VAL(p) case(p): s = #p; break;
	switch (value){
		PROCESS_VAL(Unrated);
		PROCESS_VAL(Terrible);
		PROCESS_VAL(Bad);
		PROCESS_VAL(Mediocre);
		PROCESS_VAL(Good);
		PROCESS_VAL(Exellent);
	}
#undef PROCESS_VAL

	return out << s;
}

