

#ifndef bst_h
#define bst_h

#include "bstNode.hpp"
#include "Global.h"
#include "foshow.h"
#include <deque>
#include <vector>


class bst
{
	bstNode* rootptr; // points to the top of the tree
	void reprin(bstNode*); // recurssive function for printing data from tree to output screen
	void reprinfile(bstNode*, bool final_1_temp_0);// recurssive function for printing data from tree to byname.txt
	//void reprinfiledate(bstNode*);// recurssive function for printing data from tree to bydate.txt
	//void reprinfileorganizer(bstNode*);// recurssive function for printing data from tree to temp.txt
public:
	//Constructors
	bst();
	~bst();
	//Mutators
	void addnode();
	void addnode(string movietitle, long int tickets_sold, long money_made, string opening_date, myenum unrated_terrible_bad_medicore_good_exellent, string how_you_want_organ);// last parameter used for organizing by name or date
	void deleteall(bstNode* rootptr); // recurssive function that deletes all nodes (Does not set rootptr to NULL)
	void organizeby(string how_you_want_organ_irrelevant_if_bool_is_1,bool beforetreeprint1_or_Not0); // Does not print anything to file! Must do that before
	bstNode* findNode(bstNode*, string&);
	bstNode* search(string);
	void removemenue();
	bstNode* removenode(bstNode*);
	void cleartemp();
	void bstmenue();
	//organizeby(findbesttree()); Use this for organizing your bst data in memory for the smallest tree IN MEMORY
	string findbesttree();

	int maxHeight(bstNode *p);
	string intToString(int val);
	void printBranches(int branchLen, int nodeSpaceLen, int startLen, int nodesInThisLevel, const deque<bstNode*>& nodesQueue, ostream& out);
	void printNodes(int branchLen, int nodeSpaceLen, int startLen, int nodesInThisLevel, const deque<bstNode*>& nodesQueue, ostream& out);
	void printLeaves(int indentSpace, int level, int nodesInThisLevel, const deque<bstNode*>& nodesQueue, ostream& out);
	void printPretty(bstNode *root, int level, int indentSpace, ostream& out);

	//Accessors
	void printall(string name_date); // function that prints search tree to screen in-order // choose "name" or "date" for how you want it organized
	void printtofile(bool final_or_temp);// function that prints search tree to appropriate file in-order // choose "name" or "date" for how you want it organized
};

#endif