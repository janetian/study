/** @file Main.cpp */

/*
CIS 22C
Lab3 : evaluate an infix expression
Pre :
Post:
Return:
Jie Tian and Xiaojing Liu
*/


#include <iostream>
#include <string>
#include <cctype> 
#include "Stack.h"

// compare the precedence of operators
int precedence(char op)
{
	switch (op)
	{
	case '(':
		return 0;
	case '+':
	case '-':
		return 1;
	case '*':
	case '/':
		return 2;
	case ')':
		return 3;
	default:
		return -1;
	}
}

// calculate the result
int getResult(char op, int a, int b)
{
	int result;
	switch (op)
	{
	case '+':
		result = a + b;
		break;
	case '-':
		result = a - b;
		break;
	case '*':
		result = a * b;
		break;
	case '/':
		result = a / b;
		break;
	}
	return result;
}

// evaluate the infix expression
int infixEval(std::string str)
{
	Stack<char> opStack;  // stack to hold operators
	Stack<int> valStack;   // stack to hold operands
	int operand1; 
	int operand2;
	int result;
	char op;
	for (int i = 0; i < str.length(); i++)      // walk through the expression
	{
		if (isdigit(str[i]))   // char is a number
		{
			valStack.push(str[i] - '0');  // convert the char to int and push to value stack
		}
		else     // char is a operators
		{
			switch (str[i])
			{
			case '(':
				opStack.push(str[i]);
				break;
			case '+':
			case '-':
			case '*':
			case '/':
				if (opStack.isEmpty())
				{
					opStack.push(str[i]);
				}
				else if (precedence(str[i]) > precedence(opStack.peek()))
				{
					opStack.push(str[i]);
				}
				else    // calcalute
				{
					while (!opStack.isEmpty() && precedence(str[i]) <= precedence(opStack.peek()))
					{
						operand2 = valStack.peek();  // save the value from the top of value stack
						valStack.pop();              // pop the char
						operand1 = valStack.peek();  // get the second value
						valStack.pop();      
						op = opStack.peek();         // get the operater
						opStack.pop();
						result = getResult(op, operand1, operand2);  // call the result function to calculate 
						valStack.push(result);   // push the result to value stack
					}
				}
				break;
			case ')':
				while (opStack.peek() != '(')  // calculate
				{
					operand2 = valStack.peek();  // save the value of the top value stack
					valStack.pop();              // pop the char
					operand1 = valStack.peek();
					valStack.pop();
					op = opStack.peek();
					opStack.pop();
					result = getResult(op, operand1, operand2);
					valStack.push(result);
				}
				opStack.pop();
				break;
			}
		}
	}
	while (!opStack.isEmpty())    // calculate
	{
		operand2 = valStack.peek();  // save the value of the top value stack
		valStack.pop();              // pop the char
		operand1 = valStack.peek();
		valStack.pop();
		op = opStack.peek();
		opStack.pop();
		result = getResult(op, operand1, operand2);
		valStack.push(result);
		result = valStack.peek();
	}
	return result;
}

int main()
{
	// Test the infixEval function
	std::string myExpression1 = "5+(3+4)*5";
	std::cout << "The result of expression 5+(3+4)*5 is " << infixEval(myExpression1) << std::endl << std::endl;;

	std::string myExpression2 = "9-(3+4)*1";
	std::cout << "The result of expression 9-(3+4)*1 is " << infixEval(myExpression2) << std::endl << std::endl;

	std::string myExpression3 = "(6*(2+5))/3";
	std::cout << "The result of expression (6*(2+5))/3 is " << infixEval(myExpression3) << std::endl << std::endl;


	system("pause");
	return 0;
}
